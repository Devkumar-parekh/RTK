import axios from 'axios';
import { useEffect, useMemo, useState } from 'react';
import { useDispatch,useSelector } from 'react-redux';
import { addUser,delUser,delAll,setInitial } from './store/slices/userSlice';
function App() {

  const [userDetails, setUserDetails] = useState({nameip:'',phoneip:''});
  const myState = useSelector((state) => {
    return state.users;
  });
  // const temp = myState[myState.length - 1];
  const dispatch = useDispatch();
  
  const getData = async () => {
    const res = await axios("http://localhost:3005/userdata")
      dispatch(setInitial(res.data))
  }


// getData();
  useEffect(() => {
      getData();
  },[]);
  const showData = () => {
    return myState.map((val,index) => {
      return (
        <li key={index}>
          {val.name} <button onClick={() => { dispatch(delUser({ index,id:val.id}))}}>Delete</button>
        </li>);
    });
  }
  const updateIp = (e) => {
    const inputname = e.target.name;
    const inputvalue = e.target.value;
    setUserDetails((prev) => {
      return {...prev,[inputname]:inputvalue}
    });
  }
  return (
    <div className="App">
      <form onSubmit={(e) => {
        e.preventDefault();
          dispatch(addUser({name:userDetails.nameip,id:userDetails.phoneip}));
          setUserDetails({nameip:'',phoneip:''});
          }}>

      
        <input name='nameip' value={userDetails.nameip} onChange={updateIp} />
        <input name='phoneip' type='tel' value={userDetails.phoneip} onChange={updateIp} />
        <button type='submit'>Add User</button>
      </form>
      <ol>
        {showData()}
      </ol>
      <button onClick={() => { dispatch(delAll()) }}>Delete All</button>
    </div>
  );
}

export default App;
