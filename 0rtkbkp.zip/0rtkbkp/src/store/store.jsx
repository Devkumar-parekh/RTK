import { configureStore } from '@reduxjs/toolkit';

import  usersSlicesReducer  from './slices/userSlice';


const store = configureStore({
    reducer: {
        users: usersSlicesReducer,
    }
});

export default store;