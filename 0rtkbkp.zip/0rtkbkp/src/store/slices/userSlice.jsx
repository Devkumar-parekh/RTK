import { createSlice } from "@reduxjs/toolkit"
import axios from "axios";


const usersSlices = createSlice({
    name: "user",
    initialState: [],
    reducers: {
        setInitial(state, action) {
            action.payload.map((val) => {
                return state.push(val);
            });
        },
        addUser(state, action) {
            // state.push(action.payload);
            // console.log(action.payload);
            // axios.post('http://localhost:3005/userdata')
            axios.post('http://localhost:3005/userdata', action.payload)
                .then(function (response) {
                    // console.log(response);
                    return [...state, action.payload];
                })
                .catch((err) => {
                    console.log(err.message);
                });
            
        },
        delUser(state, action) {
            state.splice(action.payload.index, 1);
            console.log(action.payload.id);
            axios.delete(`http://localhost:3005/userdata/${action.payload.id}`)
                // axios.delete(`http://localhost:3005/userdata/1`)
                .then(
                // Observe the data keyword this time. Very important
                // payload is the request body
                // Do something
            ).catch((err) => { console.log(err.message); });
                
            
        },
        delAll(state, action) {
            return [];
        }
    }
});


export default usersSlices.reducer;

export const { addUser, delUser,delAll ,setInitial} = usersSlices.actions;